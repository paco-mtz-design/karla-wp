<div class="social_share">
	<a class="social_facebook" href="#">Compartir en Facebook</a>
	<a class="social_pinterest" href="#">Compartir en Pinterest</a>
</div>
